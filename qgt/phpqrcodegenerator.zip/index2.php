<?php
include "phpqrcode/qrlib.php";
QRcode::png ("http:www.webcodegeeks.com " , "test.png ", "L", 5, 5) ;

?>