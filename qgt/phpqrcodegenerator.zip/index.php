<?php
include "phpqrcode/qrlib.php";
// create a QR Code with this text and display it
QRcode::png("MY FIRST PHP QR CODE GENERATOR EXAMPLE") ;
?>